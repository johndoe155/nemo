/**
 * Black Hole Simulation - Main Entry Point
 *
 * Sets up Three.js WebGPU renderer, camera controls, and post-processing.
 *
 * All simulation parameters are read from the dedicated configuration file
 * (blackhole.config.js), which is the single source of truth. The previous
 * Tweakpane control menu has been removed from the user-facing UI.
 */

import * as THREE from 'three/webgpu';
import { pass } from 'three/tsl';
import { bloom } from 'three/addons/tsl/display/BloomNode.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { BlackHoleSimulation } from './blackhole.js';
import { CameraAnimation } from './camera-animation.js';
import { flatSimulationConfig as config } from './blackhole.config.js';

// ============================================================================
// SCENE SETUP
// ============================================================================

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(
  60,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.set(0, -5, 20);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGPURenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
document.body.appendChild(renderer.domElement);

// ============================================================================
// ORBIT CONTROLS
// ============================================================================

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.rotateSpeed = -0.5;
controls.minDistance = 5;
controls.maxDistance = 50;
controls.target.set(0, 0, 0);

// ============================================================================
// CAMERA ANIMATION
// ============================================================================

const cameraAnimation = new CameraAnimation(camera, controls);

// Cinematic mode is now a static config option (config.camera.cinematicMode).
// It was previously a toggle button in the removed control menu.
if (config.cinematicMode) {
  cameraAnimation.start();
}

// ============================================================================
// POST-PROCESSING
// ============================================================================

let postProcessing = null;
let bloomPassNode = null;

function setupBloom() {
  if (!postProcessing) return;

  const scenePass = pass(scene, camera);
  const scenePassColor = scenePass.getTextureNode();

  bloomPassNode = bloom(scenePassColor);
  bloomPassNode.threshold.value = config.bloomThreshold;
  bloomPassNode.strength.value = config.bloomStrength;
  bloomPassNode.radius.value = config.bloomRadius;

  postProcessing.outputNode = scenePassColor.add(bloomPassNode);
}

// ============================================================================
// BLACK HOLE SIMULATION
// ============================================================================

const blackHoleSimulation = new BlackHoleSimulation(scene);
blackHoleSimulation.createBlackHole();

// ============================================================================
// ANIMATION LOOP
// ============================================================================

let lastFrameTime = performance.now();

function animate() {
  requestAnimationFrame(animate);

  const currentTime = performance.now();
  const deltaTime = Math.min((currentTime - lastFrameTime) / 1000, 0.033);
  lastFrameTime = currentTime;

  // Update camera animation (if playing)
  cameraAnimation.update(deltaTime);

  // Update controls (only effective when animation not playing)
  controls.update();

  // Update black hole simulation
  blackHoleSimulation.update(deltaTime, camera);

  // Render
  if (postProcessing) {
    postProcessing.render();
  } else {
    renderer.render(scene, camera);
  }
}

// ============================================================================
// WINDOW RESIZE
// ============================================================================

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  blackHoleSimulation.onResize(window.innerWidth, window.innerHeight);
});

// ============================================================================
// INITIALIZATION
// ============================================================================

renderer.init().then(() => {
  postProcessing = new THREE.PostProcessing(renderer);
  setupBloom();
  animate();
}).catch(err => {
  console.error('Failed to initialize WebGPU renderer:', err);
  // Show fallback message
  document.body.innerHTML = `
    <div style="color: white; padding: 20px; text-align: center;">
      <h1>WebGPU Not Supported</h1>
      <p>This demo requires a browser with WebGPU support.</p>
      <p>Try Chrome 113+ or Edge 113+ on desktop.</p>
    </div>
  `;
});
