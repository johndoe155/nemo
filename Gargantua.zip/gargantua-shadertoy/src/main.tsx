import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { ShaderCanvas } from './components/ShaderCanvas'
import './index.css'

// StrictMode double-invokes effects in development, exercising the renderer's
// dispose/re-create path on hot reload.
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ShaderCanvas />
  </StrictMode>,
)
