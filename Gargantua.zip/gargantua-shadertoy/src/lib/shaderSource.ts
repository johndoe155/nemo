/**
 * Shadertoy source — "Gargantua With HDR Bloom" by sonicether (Stephen Hill),
 * 2016-04-07, https://www.shadertoy.com/view/lstSRS — CC BY-NC-SA 3.0.
 *
 * Bundled locally (no runtime fetch). Buffers B/C/D are verbatim; Buffer A
 * (raymarcher) and Image (composite) are modified:
 *   - Buffer A: orbit camera (uCamera), aspect-aware framing, MOBILE_QUALITY
 *     iteration tier, uFeedbackReset temporal-blend skip.
 *   - Image: one-time entrance ramp (uEntrance).
 *
 * Pass graph: A (raymarch + self-feedback iChannel2) -> B (mipmap bloom)
 * -> C (H blur) -> D (V blur) -> Image (recomposite + tonemap).
 * Uniforms: iTime/iResolution/iMouse + uCamera/uEntrance/uFeedbackReset,
 * mapped to Three.js by the wrapper in gargantuaRenderer.ts.
 */

import bufferASource from './shaders/bufferA.glsl?raw'
import bufferBSource from './shaders/bufferB.glsl?raw'
import bufferCSource from './shaders/bufferC.glsl?raw'
import bufferDSource from './shaders/bufferD.glsl?raw'
import imageSource from './shaders/image.glsl?raw'

import noiseTextureUrl from '../assets/color_noise.png'
import diskTextureUrl from '../assets/london.png'

/** Bundle-local channels (mirrors Shadertoy's channel inputs for lstSRS). */
export const CHANNEL_TEXTURES = {
  /** iChannel0: 256x256 RGBA white-noise LUT (iq's noise()). */
  noise: noiseTextureUrl,
  /** iChannel1: photo modulating the accretion-disk streaks. */
  diskPhoto: diskTextureUrl,
} as const

export interface ShadertoyPassSource {
  name: 'A' | 'B' | 'C' | 'D' | 'Image'
  source: string
}

export const SHADERTOY_PASSES: readonly ShadertoyPassSource[] = [
  { name: 'A', source: bufferASource },
  { name: 'B', source: bufferBSource },
  { name: 'C', source: bufferCSource },
  { name: 'D', source: bufferDSource },
  { name: 'Image', source: imageSource },
] as const
