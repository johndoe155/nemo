import { useRef, useMemo, useEffect, useState } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  useMotionTemplate,
  type MotionValue,
} from "framer-motion";

/* -------------------- Types -------------------- */
export interface PhotoData {
  url: string;
  text: string;
  pos?: string;
  by: string;
}

export interface GalleryItem {
  common: string;
  binomial: string;
  photo: PhotoData;
}

interface CircularGalleryProps {
  items: GalleryItem[];
  bend?: number;
  textColor?: string;
  borderRadius?: number;
}

interface CardProps {
  item: GalleryItem;
  index: number;
  total: number;
  radius: number;
  rotation: MotionValue<number>;
  borderRadius?: number;
  cardW: number;
  cardH: number;
}

/* -------------------- Card -------------------- */
function Card({
  item,
  index,
  total,
  radius,
  rotation,
  borderRadius,
  cardW,
  cardH,
}: CardProps) {
  const angle = useMemo(() => (index * 360) / total, [index, total]);

  const normalized = useTransform(rotation, (r: number) => {
    const current = angle + r;
    const norm = ((current % 360) + 540) % 360 - 180;
    return norm;
  });

  const absAngle = useTransform(normalized, (n: number) => Math.abs(n));

  const opacity = useTransform(absAngle, [0, 60, 120, 180], [1, 0.92, 0.45, 0.18]);
  const scale = useTransform(absAngle, [0, 180], [1, 0.82]);
  const zIndex = useTransform(absAngle, (v: number) => 200 - Math.round(v));
  const brightness = useTransform(absAngle, [0, 90, 180], [1, 0.85, 0.35]);
  const blur = useTransform(absAngle, [0, 80, 180], [0, 0, 1.6]);
  const saturate = useTransform(absAngle, [0, 180], [1, 0.6]);

  const filter = useMotionTemplate`brightness(${brightness}) saturate(${saturate}) blur(${blur}px)`;

  const safeRadius = Number.isFinite(radius) && radius > 100 ? radius : 600;

  return (
    <motion.div
      className="absolute left-0 top-0 select-none"
      style={{
        width: cardW,
        height: cardH,
        marginLeft: -cardW / 2,
        marginTop: -cardH / 2,
        transform: `rotateY(${angle}deg) translateZ(${safeRadius}px)`,
        transformStyle: "preserve-3d",
        zIndex,
        backfaceVisibility: "hidden",
      }}
    >
      {/* Inner - no will-change, filter here to avoid flattening outer 3D */}
      <motion.div
        className="relative w-full h-full overflow-hidden bg-neutral-900 shadow-[0_28px_80px_-22px_rgba(0,0,0,0.7),0_12px_28px_-12px_rgba(0,0,0,0.6)] ring-1 ring-white/10"
        style={{
          borderRadius: borderRadius ?? 12,
          scale,
          opacity,
          filter,
          // Ensure crisp rasterization
          WebkitFontSmoothing: "antialiased",
        }}
      >
        <img
          src={item.photo.url}
          alt={item.common}
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
          loading="eager"
          decoding="async"
          style={{
            objectPosition: item.photo.pos || "center",
            // Force high-res rendering
            imageRendering: "auto" as any,
          }}
        />

        <div className="absolute inset-0 opacity-50 mix-blend-multiply bg-[radial-gradient(120%_80%_at_50%_20%,transparent_60%,rgba(0,0,0,0.55)_100%)]" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

        <div className="absolute bottom-0 left-0 w-full p-4">
          <h3 className="font-bold text-[18px] md:text-[20px] leading-[1.1] text-white tracking-tight [text-rendering:optimizeLegibility] antialiased">
            {item.common}
          </h3>
          <p className="italic text-[12px] md:text-[13px] text-white/80 mt-1 font-medium tracking-wide antialiased">
            {item.binomial}
          </p>
          <p className="text-[10px] md:text-[11px] text-white/50 mt-2 tracking-wide antialiased">
            Photo by: {item.photo.by}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* -------------------- Main Gallery -------------------- */
export default function CircularGallery({
  items,
  bend = 0,
  borderRadius = 12,
}: CircularGalleryProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  const rotation = useMotionValue(0);
  const springRotation = useSpring(rotation, {
    damping: 34,
    stiffness: 110,
    mass: 0.9,
  });

  const isDraggingRef = useRef(false);
  const startXRef = useRef(0);
  const startRotationRef = useRef(0);
  const lastXRef = useRef(0);
  const lastTimeRef = useRef(0);
  const velocityRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  // Auto-spin
  const autoSpinRafRef = useRef<number | null>(null);
  const isAutoSpinPausedRef = useRef(false);
  const autoSpinResumeTimeoutRef = useRef<number | null>(null);
  const AUTO_SPIN_SPEED = 0.038;
  const AUTO_SPIN_RESUME_DELAY = 1800;

  // High-res base size - 400x600 minimum per spec
  const [cardSize, setCardSize] = useState({ w: 420, h: 630 });
  const [galleryScale, setGalleryScale] = useState(1);
  const [perspective, setPerspective] = useState(1800);

  useEffect(() => {
    const updateSize = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      // High-res cards - always >=400x600 for crisp rasterization
      if (vw < 640) {
        setCardSize({ w: 400, h: 600 });
        // Downscale container to fit viewport instead of pushing cards closer
        const scale = Math.min(1, Math.min(vw / 520, vh / 780));
        setGalleryScale(scale * 0.92);
        setPerspective(1600);
      } else if (vw < 1024) {
        setCardSize({ w: 420, h: 630 });
        const scale = Math.min(1, Math.min(vw / 900, vh / 900));
        setGalleryScale(scale * 0.9);
        setPerspective(1800);
      } else {
        setCardSize({ w: 440, h: 660 });
        const scale = Math.min(1, Math.min(vw / 1200, vh / 900));
        setGalleryScale(Math.max(0.75, scale));
        setPerspective(2000);
      }
    };
    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, []);

  // Radius with increased spacing
  const radius = useMemo(() => {
    const count = Math.max(items.length, 1);
    if (count === 1) return 0;
    const gap = 64; // increased spacing
    const w = cardSize.w;
    const base = (w + gap) / (2 * Math.tan(Math.PI / count));
    const clamped = Math.max(base, 520);
    const bent = clamped * (1 - bend * 0.12);
    const expanded = bent * 1.35;
    const finalRadius = Math.max(expanded, 300);
    if (!Number.isFinite(finalRadius) || finalRadius < 150) return 680;
    return finalRadius;
  }, [items.length, cardSize.w, bend]);

  const stopMomentum = () => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  };

  const startMomentum = () => {
    stopMomentum();
    let vel = velocityRef.current;
    if (Math.abs(vel) < 0.005) return;
    const friction = 0.96;
    const animate = () => {
      vel *= friction;
      if (Math.abs(vel) < 0.008) {
        stopMomentum();
        pauseAutoSpin(AUTO_SPIN_RESUME_DELAY);
        return;
      }
      rotation.set(rotation.get() + vel * 16.666);
      velocityRef.current = vel;
      rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);
  };

  const stopAutoSpin = () => {
    if (autoSpinRafRef.current) {
      cancelAnimationFrame(autoSpinRafRef.current);
      autoSpinRafRef.current = null;
    }
  };

  const startAutoSpin = () => {
    if (autoSpinRafRef.current) return;
    const animate = () => {
      if (!isDraggingRef.current && !isAutoSpinPausedRef.current) {
        rotation.set(rotation.get() + AUTO_SPIN_SPEED);
      }
      autoSpinRafRef.current = requestAnimationFrame(animate);
    };
    autoSpinRafRef.current = requestAnimationFrame(animate);
  };

  const pauseAutoSpin = (delay = AUTO_SPIN_RESUME_DELAY) => {
    isAutoSpinPausedRef.current = true;
    if (autoSpinResumeTimeoutRef.current) {
      clearTimeout(autoSpinResumeTimeoutRef.current);
    }
    autoSpinResumeTimeoutRef.current = window.setTimeout(() => {
      isAutoSpinPausedRef.current = false;
    }, delay) as unknown as number;
  };

  useEffect(() => {
    startAutoSpin();
    return () => {
      stopAutoSpin();
      if (autoSpinResumeTimeoutRef.current) {
        clearTimeout(autoSpinResumeTimeoutRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    isAutoSpinPausedRef.current = true;
    if (autoSpinResumeTimeoutRef.current) {
      clearTimeout(autoSpinResumeTimeoutRef.current);
    }
    startXRef.current = e.clientX;
    startRotationRef.current = rotation.get();
    lastXRef.current = e.clientX;
    lastTimeRef.current = performance.now();
    velocityRef.current = 0;
    stopMomentum();
    (e.target as Element).setPointerCapture(e.pointerId);
    if (containerRef.current) containerRef.current.style.cursor = "grabbing";
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - startXRef.current;
    const sensitivity = 0.32;
    rotation.set(startRotationRef.current + deltaX * sensitivity);

    const now = performance.now();
    const dt = now - lastTimeRef.current;
    if (dt > 0) {
      const dx = e.clientX - lastXRef.current;
      velocityRef.current = (dx / dt) * sensitivity;
      lastXRef.current = e.clientX;
      lastTimeRef.current = now;
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {}
    if (containerRef.current) containerRef.current.style.cursor = "grab";
    startMomentum();
    pauseAutoSpin(AUTO_SPIN_RESUME_DELAY);
  };

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    let wheelRaf: number | null = null;
    let wheelVelocity = 0;
    let wheelIdleTimeout: number | null = null;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      isAutoSpinPausedRef.current = true;
      stopMomentum();
      if (wheelRaf) cancelAnimationFrame(wheelRaf);
      if (wheelIdleTimeout) clearTimeout(wheelIdleTimeout);

      let deltaY = e.deltaY;
      if (e.deltaMode === 1) deltaY *= 16;
      else if (e.deltaMode === 2) deltaY *= 80;

      const sensitivity = 0.22;
      const delta = deltaY * sensitivity;
      wheelVelocity = delta * 0.09;

      rotation.set(rotation.get() + delta);

      const decay = () => {
        wheelVelocity *= 0.92;
        if (Math.abs(wheelVelocity) < 0.01) {
          wheelRaf = null;
          wheelIdleTimeout = window.setTimeout(() => {
            isAutoSpinPausedRef.current = false;
          }, AUTO_SPIN_RESUME_DELAY) as unknown as number;
          return;
        }
        rotation.set(rotation.get() + wheelVelocity * 16.666);
        wheelRaf = requestAnimationFrame(decay);
      };

      wheelIdleTimeout = window.setTimeout(() => {
        wheelRaf = requestAnimationFrame(decay);
      }, 80) as unknown as number;
    };

    el.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      el.removeEventListener("wheel", onWheel);
      if (wheelRaf) cancelAnimationFrame(wheelRaf);
      if (wheelIdleTimeout) clearTimeout(wheelIdleTimeout);
      stopMomentum();
    };
  }, [rotation]);

  useEffect(() => {
    return () => stopMomentum();
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[100vh] min-h-[600px] overflow-hidden bg-[#0a0a0a] select-none touch-none"
      style={{
        perspective: `${perspective}px`,
        perspectiveOrigin: "50% 50%",
        cursor: "grab",
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
      onPointerCancel={handlePointerUp}
    >
      {/* Scaled wrapper - downscale high-res cards to fit viewport, keeping crisp rasterization */}
      <div
        className="absolute inset-0"
        style={{
          transform: `scale(${galleryScale})`,
          transformOrigin: "50% 50%",
          transformStyle: "preserve-3d",
        }}
      >
        {/* 3D Cylinder - ZERO-PLANE FIX: translateZ(-radius) so front card sits at Z=0 */}
        <motion.div
          className="absolute left-1/2 top-1/2 w-0 h-0"
          style={{
            transformStyle: "preserve-3d",
            rotateY: springRotation,
            z: -radius, // <-- critical: front card at Z=0, no upscale blur
          }}
        >
          {items.map((item, i) => (
            <Card
              key={`${item.common}-${i}-${item.binomial}`}
              item={item}
              index={i}
              total={items.length}
              radius={radius}
              rotation={springRotation}
              borderRadius={borderRadius}
              cardW={cardSize.w}
              cardH={cardSize.h}
            />
          ))}
        </motion.div>
      </div>
    </div>
  );
}
