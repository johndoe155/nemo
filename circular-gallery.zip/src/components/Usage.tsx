import CircularGallery, { type GalleryItem } from "./CircularGallery";

/* Sample data - 12 animals with Unsplash images */
const animalItems: GalleryItem[] = [
  {
    common: "Lion",
    binomial: "Panthera leo",
    photo: {
      url: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?q=80&w=800&auto=format&fit=crop",
      text: "Majestic male lion in savanna",
      pos: "center 20%",
      by: "David Clode",
    },
  },
  {
    common: "Arctic Fox",
    binomial: "Vulpes lagopus",
    photo: {
      url: "https://images.unsplash.com/photo-1474511320723-9a56873867b5?q=80&w=800&auto=format&fit=crop",
      text: "Arctic fox in snow",
      pos: "center",
      by: "Jonatan Pie",
    },
  },
  {
    common: "African Elephant",
    binomial: "Loxodonta africana",
    photo: {
      url: "https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?q=80&w=800&auto=format&fit=crop",
      text: "Elephant herd at sunset",
      pos: "center",
      by: "David Clode",
    },
  },
  {
    common: "Giraffe",
    binomial: "Giraffa camelopardalis",
    photo: {
      url: "https://images.unsplash.com/photo-1547721064-da6cfb341d50?q=80&w=800&auto=format&fit=crop",
      text: "Giraffe against sky",
      pos: "center top",
      by: "Hans-Juergen Mager",
    },
  },
  {
    common: "Zebra",
    binomial: "Equus quagga",
    photo: {
      url: "https://images.unsplash.com/photo-1501705388883-4ed8a543392c?q=80&w=800&auto=format&fit=crop",
      text: "Zebra pattern closeup",
      pos: "center",
      by: "Smit Patel",
    },
  },
  {
    common: "Giant Panda",
    binomial: "Ailuropoda melanoleuca",
    photo: {
      url: "https://images.unsplash.com/photo-1564349683136-77e08dba1ef7?q=80&w=800&auto=format&fit=crop",
      text: "Panda eating bamboo",
      pos: "center",
      by: "Jiachen Lin",
    },
  },
  {
    common: "Gray Wolf",
    binomial: "Canis lupus",
    photo: {
      url: "https://images.unsplash.com/photo-1564166174574-a6df0d2817d3?q=80&w=800&auto=format&fit=crop",
      text: "Wolf in forest",
      pos: "center",
      by: "Daiga Ellaby",
    },
  },
  {
    common: "Leopard",
    binomial: "Panthera pardus",
    photo: {
      url: "https://images.unsplash.com/photo-1505142468610-359e7bcbe29c?q=80&w=800&auto=format&fit=crop",
      text: "Leopard on tree",
      pos: "center",
      by: "Andy Holmes",
    },
  },
  {
    common: "Red Panda",
    binomial: "Ailurus fulgens",
    photo: {
      url: "https://images.unsplash.com/photo-1548759515-0d0d3f68cf13?q=80&w=800&auto=format&fit=crop",
      text: "Red panda climbing",
      pos: "center",
      by: "Sanjeevan Satheeskaran",
    },
  },
  {
    common: "Snowy Owl",
    binomial: "Bubo scandiacus",
    photo: {
      url: "https://images.unsplash.com/photo-1543549790-8b5f4a028cfb?q=80&w=800&auto=format&fit=crop",
      text: "Snowy owl in flight",
      pos: "center",
      by: "Ray Hennessy",
    },
  },
  {
    common: "Mountain Gorilla",
    binomial: "Gorilla beringei",
    photo: {
      url: "https://images.unsplash.com/photo-1546146020-0d6fb43af2b3?q=80&w=800&auto=format&fit=crop",
      text: "Gorilla portrait",
      pos: "center top",
      by: "Hu Chen",
    },
  },
  {
    common: "Humpback Whale",
    binomial: "Megaptera novaeangliae",
    photo: {
      url: "https://images.unsplash.com/photo-1568430462989-44163eb1752f?q=80&w=800&auto=format&fit=crop",
      text: "Whale breaching",
      pos: "center",
      by: "Todd Cravens",
    },
  },
];

export default function Usage() {
  return (
    <div className="w-full h-screen bg-[#0a0a0a] overflow-hidden">
      {/* Gallery Only - no headers, no explanatory text, no buttons */}
      <CircularGallery
        items={animalItems}
        bend={0.5}
        borderRadius={12}
      />
    </div>
  );
}
