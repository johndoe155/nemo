# @fonts/pp-neue-machina

Self-hosted PP Neue Machina, converted to woff2. See `EULA.pdf` — a Pangram
Pangram **Web License** is required before this is used on a live site.

## Families

| CSS `font-family`        | Weights available   | Styles          |
|---------------------------|----------------------|------------------|
| `PP Neue Machina Inktrap` | 300, 400, 800         | normal, italic   |
| `PP Neue Machina Plain`   | 300, 400, 800         | normal, italic   |

Inktrap and Plain are distinct designs (ink-trap detailing vs. none), not
weight variants of each other — that's why they're separate family names.

## Usage

```js
import '@fonts/pp-neue-machina/index.css';
```

```css
.headline {
  font-family: 'PP Neue Machina Inktrap', sans-serif;
  font-weight: 800;
}
```
