# @fonts/pp-neue-montreal

Self-hosted PP Neue Montreal, converted to woff2. See `EULA.pdf` — a Pangram
Pangram **Web License** is required before this is used on a live site.

## Families

| CSS `font-family`          | Weights available          | Styles          |
|------------------------------|------------------------------|------------------|
| `PP Neue Montreal`           | 100, 300, 400, 600, 800      | normal, italic   |
| `PP Neue Montreal Text`      | 400 (Book)                   | normal, italic   |

`PP Neue Montreal Text` is a separate optical-size cut meant for smaller
body-copy sizes, not a weight variant of the main family.

## Usage

```js
import '@fonts/pp-neue-montreal/index.css';
```

```css
body {
  font-family: 'PP Neue Montreal Text', sans-serif;
}

h1 {
  font-family: 'PP Neue Montreal', sans-serif;
  font-weight: 600;
}
```
