# Local fonts workspace — PP Neue Machina & PP Neue Montreal

Two self-hosted, Fontsource-style npm packages built from your Pangram Pangram
downloads. No CDN, no hand-written `@font-face`, no `<link>` tags — each
package is a self-contained CSS entry point plus its own `woff2` files,
imported the same way you'd import a `@fontsource/*` package.

## What's inside

```
packages/
  pp-neue-machina/
    index.css        → @font-face rules for "PP Neue Machina Inktrap" and
                        "PP Neue Machina Plain" (300 / 400 / 800, normal + italic)
    files/*.woff2     → 12 converted weight/style files
    EULA.pdf
    package.json
  pp-neue-montreal/
    index.css        → @font-face rules for "PP Neue Montreal"
                        (100 / 300 / 400 / 600 / 800, normal + italic) and
                        "PP Neue Montreal Text" (400 Book, normal + italic)
    files/*.woff2     → 12 converted weight/style files
    EULA.pdf
    package.json
```

OTF → WOFF2 conversion cut every file to roughly 40–45% of its original size.

## Install into your project

If this workspace lives inside your app's repo, add it as an npm/pnpm
workspace and reference the packages by name:

```json
// your app's package.json
{
  "dependencies": {
    "@fonts/pp-neue-machina": "workspace:*",
    "@fonts/pp-neue-montreal": "workspace:*"
  }
}
```

If you'd rather keep it standalone, just copy the two folders under
`packages/` into wherever your project's local packages/workspace root is.

## Use it

```js
// entry point — once, globally
import '@fonts/pp-neue-machina/index.css';
import '@fonts/pp-neue-montreal/index.css';
```

```css
h1 {
  font-family: 'PP Neue Machina Plain', sans-serif;
  font-weight: 800; /* Ultrabold */
}

body {
  font-family: 'PP Neue Montreal Text', sans-serif;
  font-weight: 400; /* Book */
}
```

## Notes

- **Bundler CSS resolution**: `index.css` references its `woff2` files with
  relative `url()` paths (`./files/...`). Vite, webpack, Parcel, and Next.js
  all resolve these correctly when the CSS file is imported from
  `node_modules` (or a workspace package) — no extra config needed in most
  setups.
- **No subsetting**: each file ships as a single full font. If you want
  per-subset splitting (e.g. Latin vs. Latin-extended) the way Fontsource
  does for large families, that's a reasonable next step but wasn't done
  here since neither typeface documents non-Latin coverage.
- **Font-weight 350** on "PP Neue Montreal Text" Book was normalized to
  `400` in CSS since it's the only weight in that family and browsers match
  nearest available weight anyway.
